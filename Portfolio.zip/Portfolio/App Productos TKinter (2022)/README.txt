APP DE GESTIÓN DE PRODUCTOS CON TKINTER (2022):

Instrucciones de Uso:

#Ejecución Directa desde el Ejecutable:

1- Ve a la carpeta App Productos Tkinter (2022)
2- Haz doble clic en el archivo App Productos.exe
La aplicación se abrirá y podrás empezar a utilizarla de inmediato. ¡Así de fácil!

#Ejecución desde el Código Fuente:

1- Abre tu entorno de desarrollo preferido (por ejemplo, PyCharm, Visual Studio Code, etc.).
2- Abre el archivo main.py que se encuentra en la raíz del proyecto.
3- Ejecuta el archivo main.py
La aplicación se abrirá y podrás empezar a utilizarla.

#Requisitos:

No se requieren entornos virtuales ni instalación de paquetes adicionales. 
La aplicación está desarrollada en Python y utiliza la biblioteca Tkinter para la interfaz gráfica, que está incluida en la instalación estándar de Python.

Nota: El ejecutable solo es compatible con el sistema operativo Windows.

¡Disfruta utilizando App Productos para gestionar tu inventario de productos!