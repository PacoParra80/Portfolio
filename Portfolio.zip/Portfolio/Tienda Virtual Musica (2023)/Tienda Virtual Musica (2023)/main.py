
import shutil
from itertools import zip_longest
from operator import itemgetter
from flask import Flask, render_template, request, redirect, url_for, session, flash
from sqlalchemy import func
from werkzeug.security import generate_password_hash,check_password_hash

from models import Producto, Cliente, Proveedor, Pedido_Cliente, Productos_Pedido_Cliente, Cesta_Cliente, \
    Cesta_Proveedor, Pedido_Proveedor, Productos_Pedido_Proveedor
import db
import datetime
import matplotlib.pyplot as plt



app = Flask(__name__) # Servidor web de Flask
app.secret_key = "12345"

def crear_productos():
    lista_productos = [["Yamaha GB1 Black", 10500, 100, "Pianos", "Yamaha", "../static/images/yamaha_gb1_black.png"],
                       ["Kawai GL 10E/P", 11000, 100, "Pianos", "Kawai", "../static/images/kawai_gl_10ep.png"],
                       ["Steinway & Sons 0-180", 35000, 100, "Pianos", "Steinway & Sons", "../static/images/ss_o_180.png"],
                       ["Takamine EF341SC Black", 1200, 100, "Guitarras", "Takamine", "../static/images/takamine_ef3.png"],
                       ["Gibson LesPaul Standard 60s", 2300, 100, "Guitarras", "Gibson", "../static/images/lespaul_standard.png"],
                       ["ESP LTD Alexi Hexed", 2000, 100, "Guitarras", "ESP", "../static/images/esp_alexi.png"],
                       ["Fender Player Series Jazz Bass", 900, 100, "Bajos","Fender", "../static/images/fender_jazzbass.png"],
                       ["Marcus Miller V3 BK", 500, 100, "Bajos", "Marcus Miller", "../static/images/marcusmiller_v3.png"],
                       ["Jackson Concert Bass 5str", 700, 100, "Bajos", "Jackson", "../static/images/jackson_concertbass.png"],
                       ["Yamaha V7 SG34", 800, 100, "Violines", "Yamaha", "../static/images/yamaha_v7.png" ],
                       ["Roth & Junius Europe", 400, 100, "Violines", "Roth & Junius", "../static/images/rj_europe.png"],
                       ["Yamaha V5 SC34", 500, 100, "Violines", "Yamaha", "../static/images/yamaha_v5.png"],
                       ["Yamaha YTR 4335 Bb", 700, 100, "Trompetas", "Yamaha", "../static/images/yamaha_4335_bb.png"],
                       ["Bach C 180SL", 4000, 100, "Trompetas", "Bach", "../static/images/bach_180sl.png"],
                       ["Bach C 190 SL Stradivarius", 4500, 100, "Trompetas", "Bach", "../static/images/bach_190_stradivarius.png"],
                       ["Krinner Classic L", 3000, 100, "Fliscornos", "Krinner", "../static/images/krinner_classic.png"],
                       ["Miraphone 24R 1100", 2500, 100, "Fliscornos", "Miraphone", "../static/images/miraphone_24r.png"],
                       ["Krinner Prinzessin", 3700, 100, "Fliscornos", "Krinner", "../static/images/krinner_prin.png"],
                       ["Miraphone Belcanto", 10500, 100, "Tubas", "Miraphone", "../static/images/miraphone_belcanto.png"],
                       ["Yamaha YFB-621", 4000, 100, "Tubas", "Yamaha", "../static/images/yamaha_yfb.png"],
                       ["Miraphone Petruschka", 4500, 100, "Tubas", "Miraphone", "../static/images/miraphone_pet.png"],
                       ["Forestone Tenor Sax", 4000, 100, "Saxos", "Forestone", "../static/images/forestone_tenor.png"],
                       ["Yamaha YTS Tenor Sax", 1500, 100, "Saxos", "Yamaha", "../static/images/yamaha_yts_tenor.png"],
                       ["Jupiter Tenor Sax", 1500, 100, "Saxos", "Yamaha", "../static/images/jupiter_tenor.png"],
                       ["Schreiber D26 Bb", 1400, 100, "Clarinetes", "Schreiber", "../static/images/schreiber_d26.png"],
                       ["Yamaha YCL", 1200, 100, "Clarinetes", "Yamaha", "../static/images/yamaha_ycl.png"],
                       ["Schreiber D12 Bb", 1200, 100, "Clarinetes", "Schreiber", "../static/images/schreiber_d12.png"],
                       ["Jupiter JFL700", 700, 100, "Flautas", "Jupiter", "../static/images/jupiter_jfl.png"],
                       ["Pearl Quantz Flute", 1200, 100, "Flautas", "Pearl", "../static/images/pearl_quantz.png"],
                       ["Yamaha YFL Flute", 600, 100, "Flautas", "Yamaha", "../static/images/yamaha_yfl.png"],
                       ["Ludwig Clasic Maple Fab", 2800, 100, "Baterias", "Ludwig", "../static/images/ludwig_clasic.png"],
                       ["Pearl Reference Pure Rock",4700, 100, "Baterias", "Pearl", "../static/images/pearl_reference.png"],
                       ["Tama Star Drum", 4000, 100, "Baterias", "Tama", "../static/images/tama_stardrum.png"],
                       ["Sonor CAJS CB", 200, 100, "Cajones", "Sonor", "../static/images/sonor_cajs.png"],
                       ["Millenium Blackbox", 70, 100, "Cajones", "Millenium", "../static/images/millenium_blackbox.png"],
                       ["Sonor CajonPad", 30, 100, "Cajones", "Sonor", "../static/images/sonor_cajonpad.png"],
                       ["Adams 29 German", 2000, 100, "Timbales", "Adams", "../static/images/adams_29.png"],
                       ["Adams Universal Timpani", 4000, 100, "Timbales", "Adams", "../static/images/adams_univ.png"],
                       ["Adams 2PASY German", 5000, 100, "Timbales", "Adams", "../static/images/adams_2pasy.png"],
                       ["Fender Celluloid", 5, 100, "Puas", "Fender", "../static/images/fender_cell.png"],
                       ["Dunlop Acoustic", 7, 100, "Puas", "Dunlop", "../static/images/dunlop_ac.png"],
                       ["Dunlop Electric", 7, 100, "Puas", "Dunlop", "../static/images/dunlop_el.png"],
                       ["Gibson Les Paul Case", 200, 100, "Fundas", "Gibson", "../static/images/gibson_case.png"],
                       ["RockCase RC", 115, 100, "Fundas", "RockCase", "../static/images/rockcase.png"],
                       ["Fender CLSC", 200, 100, "Fundas", "Fender", "../static/images/fender_case.png"],
                       ["Tama 5A Oak", 10, 100, "Baquetas", "Tama", "../static/images/tama_5a_oak.png"],
                       ["Millenium H5A", 6, 100, "Baquetas", "Millenium", "../static/images/millenium_h5a.png"],
                       ["Tama 5A Redzone", 10, 100, "Baquetas", "Tama", "../static/images/tama_5a_red.png"],
                        ]
    for lista in lista_productos:
        producto = Producto(descripcion=lista[0],precio=lista[1],stock=lista[2],categoria=lista[3],marca=lista[4], foto=lista[5])

        db.session.add(producto)
        db.session.commit()

def comprobar_productos(): #Función que comprueba la tabla producto y añade los productos si no están creados
    query = db.session.query(Producto).all()

    if not query:
        crear_productos()
        db.session.commit()
        db.session.close()


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/login_prov")
def login_prov():
    return render_template("login_prov.html")

@app.route("/login_adm")
def login_adm():
    return render_template("login_adm.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/registro")
def registro():
    return render_template("registro.html")

@app.route("/registro_prov")
def registro_prov():
    return render_template("registro_prov.html")


@app.route("/admin")
def admin():
    return render_template("admin.html")

@app.route("/prov")
def prov():
    if "user" in session:
        proveedor = db.session.query(Proveedor).filter_by(email=session["user"]).first()
        return render_template("prov.html", proveedor=proveedor)


@app.route("/welcome")
def welcome():
    return render_template("welcome.html")

@app.route("/welcome_prov")
def welcome_prov():
    return render_template("welcome_prov.html")


@app.route("/pedido_realizado")
def pedido_realizado():
    return render_template("pedido_realizado.html")


@app.route("/shop")
def shop():
    if "user" in session:
        cliente = db.session.query(Cliente).filter_by(email=session["user"]).first()
        return render_template("shop.html", cliente=cliente)
    else:
        return "No ha iniciado sesión"



@app.route("/items", methods=["POST"]) #Método para enviar la lista de productos a la plantilla de la tienda
def items():
    categoria = request.form["items"]
    cliente = db.session.query(Cliente).filter_by(email=session["user"]).first()

    lista_items= db.session.query(Producto).filter_by(categoria=categoria).all()
    return render_template("shop.html", lista_items=lista_items, cliente=cliente)


@app.route("/registro_cliente", methods=["POST"])
def registro_cliente():
    hash_password = generate_password_hash(request.form["password"], method="sha256")
    cliente = Cliente(nombre=request.form["nombre"],
                      apellido=request.form["apellidos"],
                      direccion=request.form["direccion"],
                      email=request.form["email"],
                      password=hash_password)
    if cliente.nombre and cliente.apellido and cliente.direccion and cliente.email and cliente.password:
        db.session.add(cliente)
        db.session.commit()
        return redirect(url_for("welcome"))
    else:
        success_message = "Debe introducir todos los campos para registrarse"
        flash(success_message)
        return redirect(("registro"))


@app.route("/registro_proveedor", methods=["POST"])
def registro_proveedor():
    hash_password = generate_password_hash(request.form["password"], method="sha256")
    proveedor = Proveedor(nombre_empresa=request.form["nombre_empresa"],
                          telefono=request.form["telefono"],
                          direccion=request.form["direccion"],
                          email=request.form["email"],
                          password=hash_password,
                          descuento=request.form["descuento"])
    if proveedor.nombre_empresa and proveedor.telefono and proveedor.direccion and proveedor.email and proveedor.password and proveedor.descuento:
        db.session.add(proveedor)
        db.session.commit()
        return redirect(url_for("welcome_prov"))
    else:
        success_message = "Debe introducir todos los campos para registrarse"
        flash(success_message)
        return redirect(("registro_prov"))


@app.route("/inicio_sesion", methods=["POST"])
def inicio_sesion(email=None , password=None):
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if not email or not password:
            success_message= "Email o Password No Válido"
            flash(success_message)
            return redirect(url_for("login"))
        elif email == "administrador@musicproject.com" and password == "administrador":

            return redirect(url_for("admin"))
        else:
            sesion = db.session.query(Cliente).filter_by(email=email).first()
            comprobar_password = check_password_hash(sesion.password,password)

            if comprobar_password == True:
                session["user"]= sesion.email
                return redirect(url_for("shop"))
            else:
                success_message = "Email o Password No Válido"
                flash(success_message)
                return redirect(url_for("login"))

@app.route("/inicio_sesion_adm", methods=["POST"])
def inicio_sesion_adm(email=None , password=None):
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if email == "administrador@musicproject.com" and password == "administrador":

            return redirect(url_for("admin"))
        else:
            success_message = "Email o Password No Válido"
            flash(success_message)
            return redirect(url_for("login_adm"))



@app.route("/inicio_sesion_prov", methods=["POST"])
def inicio_sesion_prov(email=None , password=None):
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if not email or not password:
            success_message = "Email o Password No Válido"
            flash(success_message)
            return redirect(url_for("login_prov"))
        elif email == "administrador@musicproject.com" and password == "administrador":

            return redirect(url_for("admin"))

        else:
            sesion = db.session.query(Proveedor).filter_by(email=email).first()
            comprobar_password = check_password_hash(sesion.password, password)

            if comprobar_password == True:
                session["user"]= sesion.email
                return redirect(url_for("prov"))
            else:
                success_message = "Email o Password No Válido"
                flash(success_message)
                return redirect(url_for("login_prov"))


@app.route('/crear_cesta/<id>',methods=["POST"])#Método para añadir productos a la cesta
def crear_cesta(id):
    cliente = db.session.query(Cliente).filter_by(email=session["user"]).first()
    producto = db.session.query(Producto).filter_by(id_producto=id).first()
    cantidad = request.form["cantidad"]

    if int(cantidad) <= producto.stock:

        producto_cesta = Cesta_Cliente(id_producto=producto.id_producto, cantidad=cantidad, id_cliente=cliente.id_cliente)
        db.session.add(producto_cesta)
        db.session.commit()

        success_message = "¡Producto añadido a la Cesta!"
        flash(success_message)

        return render_template("shop.html", cliente=cliente)
    else:
        success_message = "¡No hay suficiente stock de este producto!"
        flash(success_message)
        return redirect(url_for("shop"))


@app.route('/cesta')#Cesta de la Compra
def cesta():
    lista_items=[]
    lista_precios=[]
    cantidad=[]
    cliente = db.session.query(Cliente).filter_by(email=session["user"]).first()
    productos = db.session.query(Cesta_Cliente).filter_by(id_cliente=cliente.id_cliente).all()

    for producto in productos:

        item = db.session.query(Producto).filter_by(id_producto=producto.id_producto).first()
        lista_items.append(item)
        cantidad.append(producto.cantidad)
        precios = item.precio * producto.cantidad
        lista_precios.append(precios)


    total = sum(lista_precios)
    items_cantidad = list(zip(lista_items, cantidad))  # Zipear las listas de productos y cantidades

    # Zipear las listas de productos y cantidades
    productos_con_cantidad = list(zip_longest(productos, items_cantidad))

    return render_template("cesta.html", cliente=cliente, total=total, productos_con_cantidad=productos_con_cantidad)


@app.route("/eliminar_de_cesta/<id>", methods=["POST"])#Método para eliminar productos de la cesta
def eliminar_de_cesta(id):
    producto = db.session.query(Cesta_Cliente).filter_by(id=id).delete()
    db.session.commit()
    return redirect(url_for("cesta"))

@app.route("/hacer_pedido_cliente")#Tramitar un pedido de la Cesta de la Compra
def hacer_pedido_cliente():
    cliente = db.session.query(Cliente).filter_by(email=session["user"]).first()
    fecha_actual = datetime.datetime.now()

    pedido = Pedido_Cliente(fecha=fecha_actual, id_cliente=cliente.id_cliente)
    db.session.add(pedido)
    db.session.commit()

    cesta = db.session.query(Cesta_Cliente).all()
    if cesta:
        for producto in cesta:
            p = Productos_Pedido_Cliente(id_producto=producto.id_producto, cantidad=producto.cantidad, id_pedido_cliente=pedido.id_pedido_cliente)
            articulo = db.session.query(Producto).filter_by(id_producto=p.id_producto).first()
            resultado_stock = articulo.stock - p.cantidad
            articulo.stock = resultado_stock
            db.session.add(p)
            db.session.commit()

        db.session.query(Cesta_Cliente).delete()
        db.session.commit()

        return redirect(url_for("pedido_realizado"))
    else:
        success_message = "No hay artículos en la Cesta"
        flash(success_message)
        return redirect(url_for("cesta"))

@app.route("/ventas_admin")#Gráficas de ventas del Área de Administración
def ventas_admin():
    productos=[]
    cantidad = []
    marcas = []
    beneficios = []
    clientes = []
    pedidos = []
    venta_cliente =[]
    articulos = []
    cantidad_art = []
    lista_cant = []

    ventas = db.session.query(Productos_Pedido_Cliente).all()
    cantidad_articulos= db.session.query(func.sum(Productos_Pedido_Cliente.cantidad), Productos_Pedido_Cliente.id_producto).group_by(Productos_Pedido_Cliente.id_producto).limit(5).all()

    for cant in cantidad_articulos:
        lista_cant.append(list(cant))

    lista_cant = sorted(lista_cant, key=itemgetter(0), reverse=True)


    for i in lista_cant:
        cantidad_art.append(i[0])
        articulo = db.session.query(Producto).filter_by(id_producto=i[1]).first()
        articulos.append(articulo.descripcion)

    for v in ventas:
        p = db.session.query(Producto).filter_by(id_producto=v.id_producto).first()
        pedido = db.session.query(Pedido_Cliente).filter_by(id_pedido_cliente=v.id_pedido_cliente).all()
        for pd in pedido:
            email = db.session.query(Cliente).filter_by(id_cliente=pd.id_cliente).all()
            for em in email:
                clientes.append(em.email)
            pedidos.append(pd.id_pedido_cliente)

            producto_cliente = db.session.query(Producto).filter_by(id_producto=v.id_producto).all()
            for prc in producto_cliente:
                venta_cliente.append(prc.precio*v.cantidad)
        productos.append(p)
        cantidad.append(v.cantidad)
        marcas.append(p.marca)

    for p,c in zip(productos,cantidad):
        b = p.precio*c
        beneficios.append(b)


    fig, ax = plt.subplots(figsize=(50,20))  # Create a figure containing a single axes.
    ax.bar(marcas, beneficios, width=0.5)
    plt.title("VENTAS POR PROVEEDOR", fontsize=48, fontweight="bold")
    plt.xlabel("Marcas", fontsize= 36, fontweight="bold")
    plt.ylabel("Ventas €", fontsize= 36, fontweight="bold")
    plt.tick_params(axis="both", labelsize=30)

    plt.savefig("grafica_ventas_prov.png")
    shutil.move("grafica_ventas_prov.png", "static/images/grafica_ventas_prov.png")

    fig, ax = plt.subplots(figsize=(50, 20))  # Create a figure containing a single axes.
    ax.bar(clientes, venta_cliente, width=0.5)
    plt.title("VENTAS POR CLIENTE", fontsize=48, fontweight="bold")
    plt.xlabel("Email", fontsize=36, fontweight="bold")
    plt.ylabel("Ventas €", fontsize=36, fontweight="bold")
    plt.tick_params(axis="both", labelsize=30)
    plt.savefig("grafica_ventas_cliente.png")
    shutil.move("grafica_ventas_cliente.png", "static/images/grafica_ventas_cliente.png")

    fig, ax = plt.subplots(figsize=(50, 20))  # Create a figure containing a single axes.
    ax.bar(articulos, cantidad_art)
    plt.title("VENTAS POR ARTICULO (Top 5)", fontsize=42, fontweight="bold")
    plt.ylabel("Cantidad", fontsize=36, fontweight="bold")
    plt.tick_params(axis="both", labelsize=30)

    ax.set_xticklabels(articulos, rotation=10, ha='right', fontsize=28)  # Rotar 45 grados y alinear a la derecha

    plt.savefig("grafica_ventas_articulo.png")
    shutil.move("grafica_ventas_articulo.png", "static/images/grafica_ventas_articulo.png")

    return render_template("ventas_admin.html")

@app.route("/gestion_compras")#Gráfica de compras a proveedores del Área de Administración
def gestion_compras():
    marcas=[]
    precio_producto = []
    cantidades = []
    cantidades_totales=[]
    descuentos = []

    lista_items = db.session.query(Producto).all()


    cantidad_articulos = db.session.query(
        func.sum(Productos_Pedido_Proveedor.cantidad),
        Productos_Pedido_Proveedor.id_producto,
        Productos_Pedido_Proveedor.id_pedido_proveedor,
        Producto.id_producto,
        Producto.marca).group_by(
        Productos_Pedido_Proveedor.id_producto, Producto.marca).where(
        Productos_Pedido_Proveedor.id_producto==Producto.id_producto).order_by(Producto.marca).all()

    for cant in cantidad_articulos:
        cantidades.append(list(cant))
        cantidades_totales.append(cant[0])
        producto = db.session.query(Producto).filter_by(id_producto=cant[1]).all()
        for prod in producto:
            precio_producto.append(prod.precio)
            marcas.append(prod.marca)
        pedido = db.session.query(Pedido_Proveedor).filter_by(id_pedido_proveedor=cant[2]).all()
        for p in pedido:
            proveedor = db.session.query(Proveedor).filter_by(id_proveedor=p.id_proveedor).all()
            for prov in proveedor:
                descuentos.append(prov.descuento)


    precios_descuentos = [x-((x*y)/100) for x,y in zip(precio_producto, descuentos)]
    gastos = [x*y for x,y in zip(precios_descuentos, cantidades_totales)]


    fig, ax = plt.subplots()  # Create a figure containing a single axes.
    ax.bar(marcas, gastos)
    plt.title("COMPRAS POR PROVEEDOR", fontsize=18, fontweight="bold")
    plt.xlabel("Marcas", fontsize=10, fontweight="bold")
    plt.ylabel("Ventas €", fontsize=10, fontweight="bold")
    plt.tick_params(axis="both", labelsize=10)

    plt.savefig("grafica_compras_prov.png")
    shutil.move("grafica_compras_prov.png", "static/images/grafica_compras_prov.png")


    return render_template("gestion_compras.html", lista_items=lista_items)


@app.route("/estad_prov")#Gráficas de Ventas del Área de Proveedores
def estad_prov():
    proveedor = db.session.query(Proveedor).filter_by(email=session["user"]).first()

    productos_vendidos=[]
    cantidad = []
    cantidad_total = []
    precio_total=[]


    articulos = db.session.query(func.sum(Productos_Pedido_Proveedor.cantidad),Productos_Pedido_Proveedor.id_producto).group_by(
        Productos_Pedido_Proveedor.id_producto).all()
    for art in articulos:
        cantidad.append(list(art))


    pedidos = db.session.query(Pedido_Proveedor).filter_by(id_proveedor=proveedor.id_proveedor).all()
    for p in pedidos:
        print(p)
        prov = db.session.query(Productos_Pedido_Proveedor).filter_by(id_pedido_proveedor=p.id_pedido_proveedor).all()
        for i in prov:

            producto= db.session.query(Producto).filter_by(id_producto=i.id_producto).all()
            for pr in producto:
                productos_vendidos.append(pr.descripcion)
                for c in cantidad:
                   if pr.id_producto==c[1]:
                       descuento = (pr.precio*proveedor.descuento)/100
                       precio = (pr.precio-descuento)*c[0]
                       precio_total.append(precio)
                       cantidad_total.append(c[0])



    fig, ax = plt.subplots()
    ax.bar(productos_vendidos, cantidad_total)
    plt.title("VENTAS POR ARTÍCULO(Unidades)", fontsize=18, fontweight="bold")
    plt.xlabel("Artículos", fontsize=10, fontweight="bold")
    plt.ylabel("Cantidad", fontsize=10, fontweight="bold")
    plt.tick_params(axis="both", labelsize=10)

    plt.savefig("estad_ventas_prov_articulos1.png")
    shutil.move("estad_ventas_prov_articulos1.png", "static/images/estad_ventas_prov_articulos1.png")

    fig, ax = plt.subplots()
    ax.bar(productos_vendidos, precio_total)
    plt.title("VENTAS POR ARTÍCULO(Beneficios)", fontsize=18, fontweight="bold")
    plt.xlabel("Artículos", fontsize=10, fontweight="bold")
    plt.ylabel("Ventas €", fontsize=10, fontweight="bold")
    plt.tick_params(axis="both", labelsize=10)

    plt.savefig("estad_ventas_prov_articulos2.png")
    shutil.move("estad_ventas_prov_articulos2.png", "static/images/estad_ventas_prov_articulos2.png")

    return render_template("estad_prov.html", proveedor=proveedor)

@app.route("/pedidos_adm")#Listado de pedidos del Área de Administración
def pedidos_adm():

    lista_cesta = db.session.query(Cesta_Proveedor).all()
    lista_pedidos = db.session.query(Pedido_Proveedor).all()


    return render_template("pedidos_adm.html", lista_cesta=lista_cesta, lista_pedidos=lista_pedidos)

@app.route("/pedir_stock/<id>",methods=["POST"])
def pedir_stock(id):
    producto = db.session.query(Producto).filter_by(id_producto=id).first()
    cantidad = request.form["cantidad"]
    proveedor = db.session.query(Proveedor).filter_by(nombre_empresa=producto.marca).first()
    precio_producto = producto.precio - ((producto.precio * proveedor.descuento)/100)

    producto_cesta = Cesta_Proveedor(id_producto=producto.id_producto, cantidad=cantidad, precio=precio_producto, id_proveedor=proveedor.id_proveedor)
    db.session.add(producto_cesta)
    db.session.commit()

    success_message = "Pedido Realizado"
    flash(success_message)


    return redirect(url_for("gestion_compras"))

@app.route("/pedidos_prov")#Pedidos prendientes de trámite del Área de Proveedores
def pedidos_prov():

    lista_precios=[]
    porcentaje_descuento = 0

    proveedor = db.session.query(Proveedor).filter_by(email=session["user"]).first()

    lista_cesta = db.session.query(Cesta_Proveedor).filter_by(id_proveedor=proveedor.id_proveedor).all()
    lista_productos =[]
    for i in lista_cesta:
        p = db.session.query(Producto).filter_by(id_producto=i.id_producto).first()
        lista_productos.append(p)

    lista_productos_cesta = list(zip(lista_productos,lista_cesta))

    for producto,cesta in lista_productos_cesta:
        porcentaje_descuento = (producto.precio*proveedor.descuento)/100
        lista_precios.append((producto.precio - porcentaje_descuento)*cesta.cantidad)


    total = sum(lista_precios)

    return render_template("pedidos_prov.html", lista_productos_cesta=lista_productos_cesta,
                           proveedor=proveedor,
                           total=total,
                           descuento=porcentaje_descuento)

@app.route("/aceptar_pedido_prov")#Tramitar pedido del Área de Proveedores y rellenar el stock
def aceptar_pedido_prov():
    proveedor = db.session.query(Proveedor).filter_by(email=session["user"]).first()
    lista_cesta = db.session.query(Cesta_Proveedor).filter_by(id_proveedor=proveedor.id_proveedor).all()
    lista_productos = []
    for i in lista_cesta:
        p = db.session.query(Producto).filter_by(id_producto=i.id_producto).first()
        lista_productos.append(p)
    fecha = datetime.datetime.now()
    pedido= Pedido_Proveedor(fecha=fecha, id_proveedor=proveedor.id_proveedor)
    db.session.add(pedido)
    db.session.commit()


    for cesta,producto in zip(lista_cesta, lista_productos):
        p = Productos_Pedido_Proveedor(id_producto=cesta.id_producto, cantidad=cesta.cantidad, id_pedido_proveedor=pedido.id_pedido_proveedor)
        producto.stock += cesta.cantidad
        db.session.add(p)
        db.session.commit()

    db.session.query(Cesta_Proveedor).filter_by(id_proveedor=proveedor.id_proveedor).delete()
    db.session.commit()

    db.session.close()

    success_message = "Pedido Aceptado"
    flash(success_message)


    return redirect(url_for("pedidos_prov"))

@app.route("/balance")
def balance():
    lista_ventas = []
    precios_venta = []
    cantidades_venta = []

    ventas = db.session.query(Productos_Pedido_Cliente.id_producto, Productos_Pedido_Cliente.cantidad, Producto.precio).where(
        Producto.id_producto == Productos_Pedido_Cliente.id_producto).all()
    for v in ventas:
        lista_ventas.append(list(v))
    for lista in lista_ventas:
        cantidades_venta.append(lista[1])
        precios_venta.append(lista[2])

    totales = [x*y for x,y in zip(cantidades_venta, precios_venta)]
    venta_total = sum(totales)

    cantidades_compra = []
    precios_compra = []
    descuentos_prov = []
    descuentos_total = []

    compras_proveedor = db.session.query(Productos_Pedido_Proveedor.id_producto,
                               Productos_Pedido_Proveedor.cantidad,
                               Productos_Pedido_Proveedor.id_pedido_proveedor).all()


    for compra in compras_proveedor:
        cant = list(compra)
        cantidades_compra.append(cant[1])
        producto = db.session.query(Producto).filter_by(id_producto=cant[0])
        for prod in producto:
            precios_compra.append(prod.precio)
        pedido = db.session.query(Pedido_Proveedor.id_proveedor).filter_by(id_pedido_proveedor=cant[2]).all()
        for ped in pedido:
            for proveedor in ped:
                desc = db.session.query(Proveedor.descuento).filter_by(id_proveedor=proveedor).all()
                for d in desc:
                    descuentos_prov.append(list(d))

    for d in descuentos_prov:
        descuentos_total += d

    precios_descontados = [x-((x*y)/100) for x,y in zip(precios_compra, descuentos_total)]
    suma_compra = [x*y for x,y in zip(precios_descontados, cantidades_compra)]
    compra_total = sum(suma_compra)


    return render_template("balance.html", venta_total=venta_total, compra_total=compra_total)

@app.route("/listado_prod_prov")#Listado de control del Área de Administración
def listado_prod_prov():
    proveedores = db.session.query(Proveedor).all()
    productos = db.session.query(Producto).all()

    return render_template("listado_prod_prov.html", proveedores=proveedores, productos=productos)

@app.route("/editar_cliente")
def editar_cliente():
    cliente = db.session.query(Cliente).filter_by(email=session["user"]).first()
    return render_template("editar_cliente.html", cliente=cliente)

@app.route("/editar_prov")
def editar_prov():
    proveedor = db.session.query(Proveedor).filter_by(email=session["user"]).first()
    return render_template("editar_prov.html", proveedor=proveedor)

@app.route("/edicion_cliente", methods=["POST"])
def edicion_cliente():
    cliente = db.session.query(Cliente).filter_by(email=session["user"]).first()

    nuevo_nombre = request.form["nuevo_nombre"]
    nuevos_apellidos = request.form["nuevos_apellidos"]
    nueva_direccion = request.form["nueva_direccion"]
    nuevo_email = request.form["nuevo_email"]
    password_actual = check_password_hash(cliente.password, request.form["password_actual"])
    nuevo_password = generate_password_hash(request.form["nuevo_password"], method="sha256")

    if nuevo_nombre:
        cliente.nombre = nuevo_nombre
        db.session.commit()
    elif nuevos_apellidos:
        cliente.apellido = nuevos_apellidos
        db.session.commit()
    elif nueva_direccion:
        cliente.direccion = nueva_direccion
        db.session.commit()
    elif nuevo_email:
        cliente.email = nuevo_email
        db.session.commit()
    elif password_actual:
        if password_actual == True and nuevo_password:
            cliente.password = nuevo_password
            db.session.commit()
        elif password_actual == True and not nuevo_password:
            cliente.password = cliente.password
            db.session.commit()
    elif password_actual == False:
        success_message = "Password Incorrecto"
        flash(success_message)
        return redirect(url_for("editar_cliente"))
    else:

        return render_template("editar_cliente.html", cliente=cliente)

    db.session.close()

    success_message = "Perfil Editado"
    flash(success_message)

    return redirect(url_for("editar_cliente"))

@app.route("/edicion_prov", methods=["POST"])
def edicion_prov():
    proveedor = db.session.query(Proveedor).filter_by(email=session["user"]).first()

    nuevo_nombre = request.form["nuevo_nombre"]
    nuevo_telefono = request.form["nuevo_telefono"]
    nueva_direccion = request.form["nueva_direccion"]
    nuevo_email = request.form["nuevo_email"]
    nuevo_descuento = request.form["nuevo_descuento"]
    password_actual = check_password_hash(proveedor.password, request.form["password_actual"])
    nuevo_password = generate_password_hash(request.form["nuevo_password"], method="sha256")

    if nuevo_nombre:
        proveedor.nombre_empresa = nuevo_nombre
        db.session.commit()
    elif nuevo_telefono:
        proveedor.telefono = nuevo_telefono
        db.session.commit()
    elif nueva_direccion:
        proveedor.direccion = nueva_direccion
        db.session.commit()
    elif nuevo_email:
        proveedor.email = nuevo_email
        db.session.commit()
    elif nuevo_descuento:
        proveedor.descuento = nuevo_descuento
        db.session.commit()
    elif password_actual:
        if password_actual == True and nuevo_password:
            proveedor.password = nuevo_password
            db.session.commit()
        elif password_actual == True and not nuevo_password:
            proveedor.password = proveedor.password
            db.session.commit()
    elif password_actual == False:
        success_message = "Password Incorrecto"
        flash(success_message)
        return redirect(url_for("editar_prov"))
    else:

        return render_template("editar_prov.html", proveedor=proveedor)

    db.session.close()

    success_message = "Perfil Editado"
    flash(success_message)

    return redirect(url_for("editar_prov"))




if __name__ == '__main__':

    db.Base.metadata.create_all(db.engine)
    app.run(debug=True)



    comprobar_productos()


















