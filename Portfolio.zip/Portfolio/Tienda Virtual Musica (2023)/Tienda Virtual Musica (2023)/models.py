from sqlalchemy import Column, Integer, String, Float, ForeignKey
import db


class Producto(db.Base):
    __tablename__ = "producto"
    __table_args__ = {"sqlite_autoincrement": True}
    id_producto = Column(Integer, primary_key=True)
    descripcion = Column(String(100), nullable=False)
    precio = Column(Float, nullable=False)
    stock = Column(Integer, nullable=False)
    categoria = Column(String(50), nullable=False)
    marca = Column(String(50), nullable=False)
    foto = Column(String(50), nullable=False)

    def __init__(self,descripcion, precio, stock, categoria, marca, foto):
        self.descripcion = descripcion
        self.precio = precio
        self.stock = stock
        self.categoria = categoria
        self.marca = marca
        self.foto = foto

    def __str__(self):
        return "'{}' -- Precio: {}€/ud".format(self.descripcion, self.precio)


class Cliente(db.Base):
    __tablename__ = "cliente"
    __table_args__ = {"sqlite_autoincrement": True}
    id_cliente = Column(Integer, primary_key=True)
    nombre = Column(String(100), nullable=False)
    apellido = Column(String, nullable=False)
    direccion = Column(String, nullable=False)
    email = Column(String, nullable=False)
    password = Column(String(200), nullable=False)


    def __init__(self, nombre, apellido, direccion, email, password):
        self.nombre = nombre
        self.apellido = apellido
        self.direccion = direccion
        self.email = email
        self.password = password

    def __str__(self):
        return "Nombre: {}, Apellido: {}€, Direccion: {}, email: {}".format(self.nombre,
                                                                            self.apellido,
                                                                            self.direccion,
                                                                            self.email)


class Proveedor(db.Base):
    __tablename__ = "proveedor"
    __table_args__ = {"sqlite_autoincrement": True}
    id_proveedor = Column(Integer, primary_key=True)
    nombre_empresa = Column(String(100), nullable=False)
    telefono = Column(String, nullable=False)
    direccion = Column(String, nullable=False)
    email = Column(String, nullable=False)
    password = Column(String(200), nullable=False)
    descuento = Column(Integer)


    def __init__(self, nombre_empresa, telefono, direccion, email, password,descuento):
        self.nombre_empresa = nombre_empresa
        self.telefono = telefono
        self.direccion = direccion
        self.email = email
        self.password = password
        self.descuento = descuento


    def __str__(self):
        return """Nombre de Empresa: {}, 
        Teléfono: {}, 
        Direccion: {}, 
        Email: {}, 
        Descuento: {}%
        """.format(self.nombre_empresa,
                   self.telefono,
                   self.direccion,
                   self.email,
                   self.descuento)


class Pedido_Cliente(db.Base):
    __tablename__ = "pedido_cliente"
    __table_args__ = {"sqlite_autoincrement": True}
    id_pedido_cliente = Column(Integer, primary_key=True)
    fecha = Column(String(100), nullable=False)
    id_cliente = Column(Integer, ForeignKey("cliente.id_cliente"), nullable=False)


    def __init__(self, fecha, id_cliente):
        self.fecha = fecha
        self.id_cliente = id_cliente


    def __str__(self):
        return "Pedido nº: {}, Fecha: {}, ID Cliente: {}".format(self.id_pedido_cliente,
                                                                 self.fecha,
                                                                 self.id_cliente)


class Pedido_Proveedor(db.Base):
    __tablename__ = "pedido_proveedor"
    __table_args__ = {"sqlite_autoincrement": True}
    id_pedido_proveedor = Column(Integer, primary_key=True)
    fecha = Column(String(100), nullable=False)
    id_proveedor = Column(Integer, ForeignKey("proveedor.id_proveedor"), nullable=False)


    def __init__(self, fecha, id_proveedor):
        self.fecha = fecha
        self.id_proveedor = id_proveedor


    def __str__(self):
        return "Pedido nº: {}, Fecha: {}, ID Proveedor: {}".format(self.id_pedido_proveedor,
                                                                   self.fecha,
                                                                   self.id_proveedor)

class Productos_Pedido_Cliente(db.Base):
    __tablename__ = "productos_pedido_cliente"
    __table_args__ = {"sqlite_autoincrement": True}
    id = Column(Integer, primary_key=True)
    id_producto = Column(Integer, ForeignKey("producto.id_producto"), nullable=False)
    cantidad = Column(Integer, nullable=False)
    id_pedido_cliente = Column(Integer, ForeignKey("pedido_cliente.id_pedido_cliente"), nullable=False)


    def __init__(self, id_producto, cantidad, id_pedido_cliente):
        self.id_producto = id_producto
        self.cantidad = cantidad
        self.id_pedido_cliente = id_pedido_cliente


    def __str__(self):
        return "Producto nº: {}, Cantidad: {}, ID Pedido Cliente: {}".format(self.id_producto,
                                                                             self.cantidad,
                                                                             self.id_pedido_cliente)

class Productos_Pedido_Proveedor(db.Base):
    __tablename__ = "productos_pedido_proveedor"
    __table_args__ = {"sqlite_autoincrement": True}
    id = Column(Integer, primary_key=True)
    id_producto = Column(Integer, ForeignKey("producto.id_producto"), nullable=False)
    cantidad = Column(Integer, nullable=False)
    id_pedido_proveedor = Column(Integer, ForeignKey("pedido_proveedor.id_pedido_proveedor"), nullable=False)


    def __init__(self, id_producto, cantidad, id_pedido_proveedor):
        self.id_producto = id_producto
        self.cantidad = cantidad
        self.id_pedido_proveedor = id_pedido_proveedor


    def __str__(self):
        return "Producto nº: {}, Cantidad: {}, ID Pedido Proveedor: {}".format(self.id_producto,
                                                                               self.cantidad,
                                                                               self.id_pedido_proveedor)


class Cesta_Cliente(db.Base):
    __tablename__ = "cesta_cliente"
    __table_args__ = {"sqlite_autoincrement": True}
    id = Column(Integer, primary_key=True)
    id_producto = Column(Integer, ForeignKey("producto.id_producto"), nullable=False)
    cantidad = Column(Integer, nullable=False)
    id_cliente = Column(Integer, ForeignKey("cliente.id_cliente"), nullable=False)


    def __init__(self, id_producto, cantidad, id_cliente):
        self.id_producto = id_producto
        self.cantidad = cantidad
        self.id_cliente = id_cliente


    def __str__(self):
        return "Producto nº: {}, Cantidad: {}".format(self.id_producto,
                                                      self.cantidad)

class Cesta_Proveedor(db.Base):
    __tablename__ = "cesta_proveedor"
    __table_args__ = {"sqlite_autoincrement": True}
    id = Column(Integer, primary_key=True)
    id_producto = Column(Integer, ForeignKey("producto.id_producto"), nullable=False)
    cantidad = Column(Integer, nullable=False)
    precio = Column(Float, nullable=False)
    id_proveedor = Column(Integer, ForeignKey("proveedor.id_proveedor"), nullable=False)


    def __init__(self, id_producto, cantidad, precio, id_proveedor):
        self.id_producto = id_producto
        self.cantidad = cantidad
        self.precio = precio
        self.id_proveedor = id_proveedor


    def __str__(self):
        return "Producto ID nº: {}, Cantidad: {}, Precio/ud: {}€".format(self.id_producto,
                                                                     self.cantidad,
                                                                     self.precio)













